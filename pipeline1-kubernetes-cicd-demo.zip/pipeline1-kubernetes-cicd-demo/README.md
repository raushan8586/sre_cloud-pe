# Jenkins Kubernetes CI/CD Demo

Architecture:

GitHub
|
Jenkins EC2
|
Docker Build
|
Docker Hub
|
Amazon EKS (eksdemo1)
|
Kubernetes Pods


## Components

- GitHub
- Jenkins
- Docker
- Docker Hub
- Kubernetes
- Amazon EKS


## Deploy manually

kubectl apply -f k8s/


## Verify

kubectl get pods -n demo

kubectl get svc -n demo


## Jenkins Credential

Create Jenkins credential:

ID:
dockerhub-creds

Type:
Username with password


Pipeline stages:

1. Checkout source
2. Build Docker image
3. Push to Docker Hub
4. Deploy to EKS
